# Python exercise

## Recommended guides

Install python3 on Mac: [link](https://docs.python-guide.org/starting/install3/osx/)

Virtual environment documentation: [link](https://docs.python.org/3/tutorial/venv.html)

Behave documentation: [link](https://behave.readthedocs.io/)

### Structure

    root/
    |-- tests/
    |   |-- features/
    |   |   |-- python_docs.feature
    |   |
    |   |-- pages/
    |   |   |-- base/
    |   |   |   |-- base_page_object.py
    |   |   |
    |   |   |-- locators.py
    |   |   |-- python_docs.py
    |   |
    |   |-- steps/
    |   |   |-- steps.py
    |   |
    |   |-- utils/
    |   |   |-- factories/
    |   |   |   |-- web_driver_factory.py
    |   |   |
    |   |   |-- constants.py
    |   |   |-- helpers.py
    |   |
    |   |-- environment.py
    |
    |-- .gitignore
    |-- README.md
    |-- requirements.txt

### Logic

Behave is a BDD (Behavior-driven development) framework, which supports tests written in a natural language style.

Behave features an `environment.py` file with methods acting as event hooks for the different stages of execution. When the `behave` command runs in the `tests/` folder, it gathers all feature entries from the `.feature` files and selects eligible ones to run; which is based on the tags passed to the command.

Steps from the feature files, selected for a test run via the tags, have their matching step definitions executed in sequence.

Behave also provides a `context` object that persist fields added to it in step logics, allowing us to save information from one step and carry it to another. (e.g. one creates test data in a step and removes said test data after a test run, the related id that is needed to remove the entry can be persisted in context, like `context.test_id = 123`)

### Technologies, notable packages

* Python 3.9+
* [behave (BDD)](https://behave.readthedocs.io/)
* [Page Object Model](https://www.selenium.dev/documentation/test_practices/encouraged/page_object_models/)
* [behave (package)](https://pypi.org/project/behave/)
* [selenium](https://pypi.org/project/selenium/)
* [webdriver-manager](https://pypi.org/project/webdriver-manager/)

## How to run

### Steps

1. Create virtual environment
2. Install requirements: ```pip3 install -r requirements.txt```
3. Navigate to the tests folder: ```cd tests```
4. (_optional_) Set `DEBUG` environmental variable to `1` to see debug messages
5. Run the tests: ```behave```

* Run tests for a specific task solution: 

    * ```behave --tags task_1```
    * ```behave --tags task_2```
    * ```behave --tags task_bonus_1```
    * ```behave --tags task_bonus_2```

### Notable environmental variables

* `SELECTED_BROWSER`; _(default: "chrome")_ accepts "chrome", "firefox" which will determine the browser selection for the tests
* `BROWSER_HEADLESS`; _(default: "False")_ accepts "True" or "False" which will set the browser's headless mode

## TODOs

For the following tasks, you will be expected to update various parts of the solution, including page object files in `tests/pages/` and related locators in `tests/pages/locators.py`, step entries in `tests/steps/steps.py`, logic in the event hook entries in `tests/environment.py`, etc.

### Task 1: Allow portal url to be passed as a parameter to steps 

1. Change the following two scenario steps to accept the portal url "https://docs.python.org/3/" as a parameter in the step and use it as a constructor parameter for the page object:
   
   * `Given The user navigates to the Python documentation portal`; _e.g. `Given The user navigates to "<portal_url>"`_
   * `When The Python documentation portal's home page loads`; _e.g. `When "<portal_url>" page loads`_

2. Change the step related definitions to accept the parameter and use it for navigation and assertion in the next step
3. Tag the related feature or scenario entries with `@task_1`

### Task 2: Validate Python 3.11 release "What's new"

1. Add feature entries, step definitions to cover the following:
   1. Navigate to `https://docs.python.org/3/whatsnew/3.11.html`
   2. Validate the release heading entries:
      1. Release: 3.11.0 
      2. Date: November 10, 2022 
      3. Editor: Pablo Galindo Salgado
   3. Validate that the page features a link to the "changelog" with url "https://docs.python.org/3/whatsnew/changelog.html#changelog"
2. Tag the related feature or scenario entries with `@task_2`

### Bonus task 1: Add support for taking screenshots if a failure occurs

1. Add a screenshot factory class to the `tests/utils/factories` folder, accepting `driver` and `constants` parameters
2. Init the new class in `tests/environment.py` (choose an event hook entry to add the init call)
3. When a step fails, use the class to take a screenshot and save it in a folder called `screenshots` 
4. Tag the by-design failing scenario entry with `@task_bonus_1`

### Bonus task 2: Validate PEP references on "What's new" page

1. Add feature entries, step definitions to cover the following:
   1. For each "PEP XXX: some link text" link entry in "Summary – Release highlights", validate:
      1. The same page features "See PEP XXX for more details." paragraphs; _e.g. the PEP number has to match_
      2. The link in the "See PEP XXX for more details." paragraphs has to correspond to the same PRP number in the url; _e.g. for "See PEP 675 for more details." the link will have to contain `pep-0675`_
2. Tag the related feature or scenario entries with `@task_bonus_2`

## Evaluation criteria

* Automation & QA best practices
* Show us your work through your commit history, on your chosen version control platform
* We're looking for you to produce working code, with enough room to demonstrate how to structure components in a small program
* Completeness: did you complete the tasks?
* Correctness: does the functionality act in sensible, thought-out ways?
* Maintainability: is it written in a clean, maintainable way?
* Completing the bonus tasks is optional
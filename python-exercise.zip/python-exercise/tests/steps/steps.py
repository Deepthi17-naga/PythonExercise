from behave import given, then, when, step

from pages.python_docs import PythonDocsPage
from utils.helpers import print_debug, print_error


@given(u'The user navigates to the "{portal_url}" portal')
def navigate_to_url(context, portal_url):
    """
    Navigates browser to url
    """
    page = PythonDocsPage(context.driver, context.constants, portal_url)
    page.visit()


@when(u'The "{portal_url}" home page loads')
def verify_page_loaded(context, portal_url):
    """
    Checks if the page loaded
    """
    page = PythonDocsPage(context.driver, context.constants, portal_url)
    assert page.check_page_loaded(), 'Page has not loaded as expected'


@then(u'The "Parts of the documentation" section displays the following entries')
def check_loaded_entries(context):
    """
    Verify loaded entries
    """
    expected_entries = [row['parts_of_documentation'] for row in context.table]

    page = PythonDocsPage(context.driver, context.constants, 'https://docs.python.org/3/')
    topic_titles = page.get_topic_link_titles_from_table(page.get_parts_of_documentation_table())

    expected_entries.sort()
    topic_titles.sort()

    assert topic_titles == expected_entries, f'Loaded topic titles don\'t match expected "{expected_entries}", actual: {topic_titles}'

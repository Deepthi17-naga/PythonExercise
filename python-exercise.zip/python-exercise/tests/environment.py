from utils.constants import Constants
from utils.helpers import print_debug
from utils.factories.web_driver_factory import WebDriverFactory

constants = Constants()


# Behave - event-hooks =================================================================================================

def before_all(context):
    print_debug('Before all')
    context.constants = constants


def before_feature(context, feature):
    print_debug('Before feature')
    print_debug('Init webdriver factory')
    context.web_driver_factory = WebDriverFactory(constants)


def after_feature(context, feature):
    print_debug('After feature')


def before_scenario(context, scenario):
    print_debug('Before scenario')
    print_debug('Init webdriver')
    context.driver = context.web_driver_factory.init_driver()


def after_scenario(context, scenario):
    print_debug('After scenario')
    print_debug('Quit webdriver')
    context.web_driver_factory.quit_driver()

    if 'passed' in str(scenario.status):
        print_debug(f'Step passed: {scenario.name}')
    if 'failed' in str(scenario.status):
        print_debug(f'Step failed: {scenario.name}')


def before_step(context, step):
    print_debug('Before step')


def after_step(context, step):
    print_debug('After step')

    if 'passed' in str(step.status):
        print_debug(f'Step passed: {step.name}')
    if 'failed' in str(step.status):
        print_debug(f'Step failed: {step.name}')


def after_all(context):
    print_debug('After all')

import traceback
import time
from typing import List

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.support import expected_conditions
from selenium.common.exceptions import *

from utils.constants import Constants
from utils.helpers import print_debug, print_error, check_if_mac_os


class BasePage(object):
    driver: WebDriver
    base_url: str
    timeout: int
    constants: Constants

    def __init__(self, driver: WebDriver, constants: Constants, base_url: str = 'https://waracle.com'):
        self.base_url = base_url
        self.driver = driver
        self.timeout = 30
        self.constants = constants

    def find_element(self, *loc) -> WebElement:
        print_debug(f'Find element: {loc}')

        return self.driver.find_element(*loc)

    def find_elements(self, *loc) -> List[WebElement]:
        print_debug(f'Find elements: {loc}')

        return self.driver.find_elements(*loc)

    def wait_for_and_find_element(self, what) -> WebElement:
        print_debug(f'Wait and find element: {what}')

        try:
            element = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.presence_of_element_located(self.locator_dictionary[what])
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        try:
            element = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.visibility_of_element_located(self.locator_dictionary[what])
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        return self.find_element(*self.locator_dictionary[what])

    def wait_for_and_find_element_with_by(self, by_what) -> WebElement:
        print_debug(f'Wait and find element with by: {by_what}')

        try:
            element = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.presence_of_element_located(by_what)
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        try:
            element = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.visibility_of_element_located(by_what)
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        return self.find_element(*by_what)

    def wait_for_and_find_element_with_by_ignoring_exceptions(self, by_what) -> WebElement:
        print_debug(f'Wait and find element with by (ignoring exceptions): {by_what}')

        ignored_exceptions = (NoSuchElementException, StaleElementReferenceException,)
        try:
            element = WebDriverWait(self.driver, self.timeout, ignored_exceptions=ignored_exceptions).until(
                expected_conditions.presence_of_element_located(by_what)
            )
        except TimeoutException:
            traceback.print_exc()

        try:
            element = WebDriverWait(self.driver, self.timeout, ignored_exceptions=ignored_exceptions).until(
                expected_conditions.visibility_of_element_located(by_what)
            )
        except TimeoutException:
            traceback.print_exc()

        return self.find_element(*by_what)

    def wait_for_and_find_element_with_exception_ignore(self, what) -> WebElement:
        print_debug(f'Wait and find element (ignoring exceptions): {what}')

        ignored_exceptions = (NoSuchElementException, StaleElementReferenceException,)
        try:
            element = WebDriverWait(self.driver, self.timeout, ignored_exceptions=ignored_exceptions).until(
                expected_conditions.presence_of_element_located(self.locator_dictionary[what])
            )
        except TimeoutException:
            traceback.print_exc()

        try:
            element = WebDriverWait(self.driver, self.timeout, ignored_exceptions=ignored_exceptions).until(
                expected_conditions.visibility_of_element_located(self.locator_dictionary[what])
            )
        except TimeoutException:
            traceback.print_exc()

        return self.find_element(*self.locator_dictionary[what])

    def wait_for_and_find_elements(self, what) -> List[WebElement]:
        print_debug(f'Wait and find elements: {what}')

        try:
            elements = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.presence_of_all_elements_located(self.locator_dictionary[what])
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        try:
            elements = WebDriverWait(self.driver, self.timeout).until(
                expected_conditions.visibility_of_all_elements_located(self.locator_dictionary[what])
            )
        except(TimeoutException, StaleElementReferenceException):
            traceback.print_exc()

        es = self.find_elements(*self.locator_dictionary[what])
        return self.find_elements(*self.locator_dictionary[what])

    def wait_for_element_disappeared(self, what):
        print_debug(f'Wait for element disappeared: {what}')

        WebDriverWait(self.driver, self.timeout).until_not(
            expected_conditions.invisibility_of_element(self.locator_dictionary[what])
        )

    def wait_for_url_to_change_to_expected(
            self,
            expected_url: str,
            tries: int = 4,
            base_wait_seconds: int = 4,
            backoff_seconds: int = 2
    ):
        print_debug(
            f'Wait for url to change to expected: {expected_url}, max tries: {tries}, base wait: {base_wait_seconds}, backoff: {backoff_seconds}'
        )

        for count in range(tries):
            wait_seconds = backoff_seconds * count + base_wait_seconds
            print_debug(f'Try {count+1} / {tries}: Comparing {self.driver.current_url} to {expected_url};'
                        f' waiting for {wait_seconds}s')
            self.explicit_wait(wait_seconds)
            if self.driver.current_url.startswith(expected_url):
                print_debug('Url matching')
                return

        print_error(
            f'Browser url did not change to the expected "{expected_url}", actual: {self.driver.current_url}'
        )

    def check_element_exists(self, *loc) -> bool:
        print_debug(f'Check element exists: {loc}')

        self.explicit_wait(2)
        elements = self.driver.find_elements(*loc)
        return len(elements) > 0

    def click_element_if_exists(
            self,
            *loc,
            tries: int = 2,
            base_wait_seconds: int = 4,
            backoff_seconds: int = 2
    ):
        print_debug(
            f"Click element if exists: {loc}{f', max tries: {tries}, base wait: {base_wait_seconds}, backoff: {backoff_seconds}' if tries > 2 else ''}"
        )

        total_waited_time = 0
        for count in range(tries):
            print_debug(f'Try {count+1} / {tries}')

            if self.check_element_exists(*loc):
                self.find_element(*loc).click()
            else:
                return

            wait_seconds = backoff_seconds * count + base_wait_seconds
            self.explicit_wait(wait_seconds)
            total_waited_time += wait_seconds

        print_error(
            f'Element "{loc}" still exists after {tries} clicks, waited a total of {total_waited_time} seconds'
        )

    def get_element_if_exists_multiple_tries(
            self,
            *loc,
            tries: int = 2,
            base_wait_seconds: int = 4,
            backoff_seconds: int = 2
    ) -> WebElement:
        print_debug(
            f"Get element if exists: {loc}{f', max tries: {tries}, base wait: {base_wait_seconds}, backoff: {backoff_seconds}' if tries > 2 else ''}"
        )

        total_waited_time = 0
        for count in range(tries):
            print_debug(f'Try {count+1} / {tries}')

            if self.check_element_exists(*loc):
                return self.find_element(*loc)

            wait_seconds = backoff_seconds * count + base_wait_seconds
            self.explicit_wait(wait_seconds)
            total_waited_time += wait_seconds

        print_error(
            f'Element "{loc}" does not exists after {tries} checks, waited a total of {total_waited_time} seconds'
        )

    def visit(self):
        print_debug(f'Visit "{self.base_url}"')

        self.driver.get(self.base_url)

    def wait(self, seconds: int = None):
        print_debug(f'Wait for {seconds}"')

        if not seconds:
            seconds = 5
        WebDriverWait(self.driver, seconds)

    @staticmethod
    def explicit_wait(seconds: int = None):
        print_debug(f'Wait (explicit) for {seconds}')

        if not seconds:
            seconds = 5
        time.sleep(seconds)

    def compare_base_url_with_current(self) -> bool:
        print_debug(f'Compare base_url "{self.base_url}" to current_url "{self.driver.current_url}"')

        return self.base_url == self.driver.current_url

    def hover(self, element, wait_seconds: int = 5):
        print_debug('Hover to element')

        ActionChains(self.driver).move_to_element(element).perform()
        # Hover is sensitive and needs some sleep time
        self.explicit_wait(wait_seconds)

    def clear_field_with_keys_on_element(self, element):
        print_debug(f'Clear field with keys on element: {element}')

        control_key = Keys.COMMAND if check_if_mac_os() else Keys.CONTROL
        element.send_keys(f'{control_key}a')
        element.send_keys(Keys.BACKSPACE)
        self.explicit_wait(2)

    def clear_field_with_keys_with_actions(self, element):
        print_debug(f'Clear field with keys (ActionChains) on element: {element}')
        control_key = Keys.COMMAND if check_if_mac_os() else Keys.CONTROL
        element.click()

        actions = ActionChains(self.driver)
        actions.key_down(control_key)
        actions.send_keys('a')
        actions.key_up(control_key)
        actions.perform()

        actions.send_keys(Keys.BACKSPACE)
        actions.perform()

        self.explicit_wait(2)

    def paste_to_element_with_actions(self, element):
        print_debug(f'Clear field with keys (ActionChains) on element: {element}')
        control_key = Keys.COMMAND if check_if_mac_os() else Keys.CONTROL
        element.click()

        actions = ActionChains(self.driver)
        actions.key_down(control_key)
        actions.send_keys('v')
        actions.key_up(control_key)
        actions.perform()

        self.explicit_wait(2)

    def send_text_to_element_with_actions(self, element, text: str):
        print_debug(f'Send text to element with ActionChains: {element}, text: {text}')

        element.click()

        actions = ActionChains(self.driver)
        actions.send_keys(text)
        actions.perform()

        self.explicit_wait(2)

    def send_text_to_element_with_actions_per_word(
            self,
            element,
            text: str,
            separator: str = ' ',
            send_separator_as_last_character: bool = True
    ):
        print_debug(
            f'Send text to element with ActionChains, per word: {element}, text: {text}, separated with "{separator}"'
        )
        words = text.split(separator)

        element.click()

        actions = ActionChains(self.driver)
        for i, word in enumerate(words):
            actions.send_keys(word)
            if i+1 < len(words) or send_separator_as_last_character:
                actions.send_keys(separator)

        actions.perform()

        self.explicit_wait(2)

    def press_key_with_actions(self, key: str):
        print_debug('Press key with ActionChains')

        actions = ActionChains(self.driver)
        actions.key_down(key)
        actions.key_up(key)
        actions.perform()

        self.explicit_wait(2)

    def hit_enter_button(self):
        print_debug('Hit "Enter" key')
        self.press_key_with_actions(Keys.ENTER)

    def hit_tab_button(self):
        print_debug('Hit "Tab" key')
        self.press_key_with_actions(Keys.TAB)

    def clear_field_by_setting_value(self, element):
        print_debug(f'Clear field by setting its value: {element}')
        self.driver.execute_script('arguments[0].value = "";', element)
        self.explicit_wait(4)

    def scroll_view_to_element_with_js(self, element):
        print_debug(f'Scroll view to element using JS: {element}')
        self.driver.execute_script('arguments[0].scrollIntoView();', element)

    def __getattr__(self, what):
        print_debug('"__getattr__" call')
        try:
            if what in self.locator_dictionary.keys():
                try:
                    element = WebDriverWait(self.driver, self.timeout).until(
                        expected_conditions.presence_of_element_located(self.locator_dictionary[what])
                    )
                except(TimeoutException, StaleElementReferenceException):
                    traceback.print_exc()

                try:
                    element = WebDriverWait(self.driver, self.timeout).until(
                        expected_conditions.visibility_of_element_located(self.locator_dictionary[what])
                    )
                except(TimeoutException, StaleElementReferenceException):
                    traceback.print_exc()
                # Could have returned the element, safer to discover it again
                return self.find_element(*self.locator_dictionary[what])
        except AttributeError:
            super(BasePage, self).__getattribute__("method_missing")(what)

    @staticmethod
    def method_missing(what):
        print_debug(f"No {what} here!")

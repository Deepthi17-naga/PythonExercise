from typing import List

from selenium.webdriver.remote.webdriver import WebDriver, WebElement
from selenium.webdriver.common.by import By

from utils.constants import Constants
from utils.helpers import print_debug
from pages.base.base_page_object import BasePage
from pages.locators import Locators


class PythonDocsPage(BasePage):
    locator_dictionary = {
        'all_elements': (By.XPATH, '//*'),
        'body': (By.TAG_NAME, Locators.body),
        'page_title': (By.CSS_SELECTOR, Locators.documentation_page_title_css),

        'parts_of_documentation_table': (By.XPATH, Locators.documentation_page_parts_of_documentation_table_xpath),
        'indices_and_tables_table': (By.XPATH, Locators.documentation_page_indices_and_tables_table_xpath),
        'meta_information_table': (By.XPATH, Locators.documentation_page_meta_information_table_xpath),
        'table_topic_links': (By.CSS_SELECTOR, Locators.documentation_page_table_topic_links_css),
    }

    def __init__(self, driver: WebDriver, constants: Constants, page_url: str):
        super().__init__(
            driver,
            constants,
            page_url,
        )

    def check_page_loaded(self) -> bool:
        print_debug('Checking if page has loaded successfully')
        return all((
            self.driver.current_url.startswith(self.base_url),
            self.get_body(),
            self.get_page_title(),
        ))

    def get_all_elements(self) -> List[WebElement]:
        print_debug('Get all elements')
        return self.find_elements(*self.locator_dictionary['all_elements'])

    def get_body(self) -> WebElement:
        print_debug('Get body element')
        return self.wait_for_and_find_element('body')
    
    def get_page_title(self) -> WebElement:
        print_debug('Get page title')
        return self.find_element(*self.locator_dictionary['page_title'])

    def get_parts_of_documentation_table(self) -> WebElement:
        print_debug('Get "parts of documentation" table')
        return self.find_element(*self.locator_dictionary['parts_of_documentation_table'])

    def get_topic_link_elements_from_table(self, table_element: WebElement) -> List[WebElement]:
        print_debug('Get topic links from passed table element')
        return table_element.find_elements(*self.locator_dictionary['table_topic_links'])

    def get_topic_link_titles_from_table(self, table_element: WebElement) -> List[str]:
        print_debug('Get topic titles from passed table element')
        return [element.text for element in self.get_topic_link_elements_from_table(table_element)]

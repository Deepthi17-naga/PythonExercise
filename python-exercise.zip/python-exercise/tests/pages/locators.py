class Locators:
    # Global
    body = 'body'

    # Documentation page
    documentation_page_title_css = 'div.body > h1'
    documentation_page_parts_of_documentation_table_xpath = '//div[@class="body"]/table[@class="contentstable"][1]'
    documentation_page_indices_and_tables_table_xpath = '//div[@class="body"]/table[@class="contentstable"][2]'
    documentation_page_meta_information_table_xpath = '//div[@class="body"]/table[@class="contentstable"][3]'
    documentation_page_table_topic_links_css = 'a.biglink'

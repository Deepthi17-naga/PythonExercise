import datetime
import os
import random
import re
import sys
import time
import uuid
import string
import json
from pathlib import Path
from typing import List
from urllib.parse import urlparse
from urllib.parse import parse_qs


def print_message_if_debug_on(msg_type, msg) -> str:
    timestamp = format_datetime_into_str(get_current_date_datetime(in_utc=False), '%Y-%m-%dT%H:%M:%S%z')
    message = f'{timestamp} [{msg_type.upper()}] {msg}'
    if os.getenv('DEBUG', 1) in ('1', 'True'):
        print(message)
    return message


def print_debug(msg: str) -> str:
    """
    Calls print() on the passed message if DEBUG is on, formatted with date, marked as debug
    Also returns the same formatted message

    @param msg: debug message used in the formatted output
    @return: same formatted debug message is also returned
    """
    return print_message_if_debug_on('debug', msg)


def print_error(msg: str) -> str:
    """
    Calls print() on the passed message if DEBUG is on, formatted with date, marked as error
    Also returns the same formatted message

    @param msg: debug message used in the formatted output
    @return: same formatted error message is also returned
    """
    return print_message_if_debug_on('error', msg)


def limit_str(original_str: str, char_limit: int = 255, suffix: str = ".."):
    limited_str: str
    if suffix:
        return (original_str[: (char_limit - len(suffix))] + suffix) if len(original_str) > char_limit else original_str

    else:
        return (original_str[:char_limit]) if len(original_str) > char_limit else original_str


def concatenate_paths(path_a: str, path_b: str) -> str:
    return os.path.join(path_a, path_b)


def get_zero_date_datetime() -> datetime.datetime:
    return datetime.datetime(1970, 1, 1)


def get_current_date_datetime(in_utc: bool = True) -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc) if in_utc else datetime.datetime.now()


def get_current_utc_date_time_formatted(date_format: str) -> str:
    current_formatted_time = datetime.datetime.now(datetime.timezone.utc).astimezone().strftime(date_format)

    if date_format[-1] == "f":
        # to cut off needlessly accurate microseconds after 3 digits
        return current_formatted_time[:-3]
    else:
        return current_formatted_time


def format_datetime_into_str(date_time: datetime.datetime, date_format: str) -> str:
    return date_time.strftime(date_format)


def parse_str_into_datetime(date_time_str: str, date_format: str) -> datetime.datetime:
    try:
        return datetime.datetime.strptime(date_time_str, date_format)
    except (TypeError, ValueError):
        return get_zero_date_datetime()


def datetime_to_epoch(d1: datetime.datetime) -> int:
    # create 1,1,1970 in same timezone as d1
    d2 = datetime.datetime(1970, 1, 1, tzinfo=d1.tzinfo)
    time_delta = d1 - d2
    return int(time_delta.total_seconds())


def format_timedelta_for_practitest_call(duration: datetime.timedelta, default: str = "00:00:00") -> str:
    # expected format: HH:MM:SS
    duration_str = str(duration)
    split_duration = duration_str.split(".")
    return split_duration[0] if len(split_duration) == 2 else default


def create_folder_if_does_not_exist(path_to_folder: str):
    Path(path_to_folder).mkdir(parents=True, exist_ok=True)


# from https://github.com/django/django/blob/master/django/utils/text.py
def get_valid_filename(s):
    """
    Return the given string converted to a string that can be used for a clean
    filename. Remove leading and trailing spaces; convert other spaces to
    underscores; and remove anything that is not an alphanumeric, dash,
    underscore, or dot.
    >>> get_valid_filename("john's portrait in 2004.jpg")
    'johns_portrait_in_2004.jpg'
    """
    s = str(s).strip().replace(' ', '_')
    return re.sub(r'(?u)[^-\w.]', '', s)


def get_file_name_from_end_of_file_path(separator: str, file_path: str):
    path_array = file_path.split(separator)
    return path_array[-1] if path_array else file_path


def get_last_created_files_in_folder(
        folder_path: str,
        with_path: bool = True,
        number_of_files_needed: int = -1,
        exception_file_name_list: tuple = (".DS_Store",)
) -> list:
    try:
        paths = sorted(Path(folder_path).iterdir(), key=os.path.getmtime)
        path_strings = []
        for p in paths:
            if p.name not in exception_file_name_list:
                if with_path:
                    path_strings.append(os.path.join(folder_path, p.name))
                else:
                    path_strings.append(p.name)
        if number_of_files_needed > 0:
            return path_strings[-number_of_files_needed:]
        else:
            # to support getting all files from the folders
            return path_strings
    except FileNotFoundError:
        return []


def fashion_url_with_slash(host: str, override_character: str = "/"):
    if not host:
        return host
    if host[-1] != override_character:
        return f"{host}{override_character}"
    else:
        return host


def remove_slash_from_the_end_of_url(host: str, override_character: str = "/"):
    return host[:-1] if host[-1] == override_character else host


def get_random_whole_number(a: int, b: int):
    return random.randint(a, b)


def get_random_list_items(array: list, number_of_items: int = 1, default=None) -> list:
    if default is None:
        default = []
    if not array:
        return default

    random_indexes = list(range(len(array)))
    random.shuffle(random_indexes)
    indexes = random_indexes[:number_of_items]

    return [array[i] for i in indexes]


def get_random_list_item(array: list, default=None):
    return get_random_list_items(array, 1)[0] if array else default


def question_or_ampersand(url: str):
    return "&" if "?" in url else "?"


def get_random_uuid(uuid_or_str: str = "str"):
    new_uuid = uuid.uuid4()
    return new_uuid if uuid_or_str == "uuid" else str(new_uuid)


def get_random_str(number_of_characters: int = 10, allow_upper_case: bool = False) -> str:
    letters = string.ascii_lowercase + string.digits
    if allow_upper_case:
        letters += string.ascii_uppercase
    return ''.join(random.choice(letters) for _ in range(number_of_characters))


def get_random_int(minimum: int, maximum: int) -> int:
    return random.randint(minimum, maximum)


def get_random_email(domain: str = "example.com") -> str:
    return f'{get_random_str(5)}.{get_random_str(6)}@{domain}'


def shuffle_list(array: list):
    random.shuffle(array)


def append_entry_to_list_under_dict_key(dictionary: dict, key: str, value):
    if key not in dictionary.keys():
        dictionary[key] = []
    dictionary[key].append(value)


def load_json_with_default(json_text: str, default):
    try:
        if json_text.startswith('\''):
            json_text = f'"{json_text[1:]}'
        if json_text.endswith('\''):
            json_text = f'{json_text[:-1]}"'

        return json.loads(json_text)
    except (json.decoder.JSONDecodeError, AttributeError):
        return default


def sleep_execution(seconds: int):
    time.sleep(seconds)


def change_str_casing_to_upper_or_lower(original_str: str, force: str = "") -> str:
    if original_str.islower() or force.lower() == "upper":
        return original_str.upper()
    elif original_str.isupper() or force.lower() == "lower":
        return original_str.lower()
    else:
        return original_str


def get_string_from_text_matching_regex(regex: str, text: str, match_group_index: int = 1, default=''):
    regex_checker = re.compile(regex)
    try:
        if match := regex_checker.search(text):
            return match[match_group_index]
        else:
            return default
    except TypeError as e:
        print(f"TypeError occurred: {e}")


def get_multiple_strings_from_text_matching_regex(regex: str, text: str, default=''):
    regex_checker = re.compile(regex)
    try:
        match = regex_checker.search(text)
        return match.groups() if match and match.groups() else default
    except TypeError as e:
        print(f"TypeError occurred: {e}")


def get_item_from_split_text(text: str, separator: str, index: int):
    try:
        return text.split(separator)[index]
    except IndexError:
        return None


def get_length_or_default(obj, default):
    try:
        return len(obj)
    except TypeError:
        return default


def check_if_mac_os() -> bool:
    return bool(sys.platform.startswith('darwin'))


def check_if_linux_os() -> bool:
    return bool(sys.platform.startswith('linux'))


def check_if_windows_os() -> bool:
    return bool(sys.platform.startswith('win'))


def increment_config_version_number(version_label: str) -> str:
    split_version_label = version_label.split('.')
    split_version_label[-1] = str(int(split_version_label[-1]) + 1)
    return '.'.join(split_version_label)


def create_file_with_content(file_name: str, content: str):
    with open(file_name, 'w') as f:
        f.write(content)


def get_random_special_str(number_of_characters: int = 20, excluded_list: List[str] = (), forced_prefix: str = None):
    specials = string.punctuation
    for excluded in excluded_list:
        specials = specials.replace(excluded, '')

    if forced_prefix:
        alphanumeric_prefix = forced_prefix[:number_of_characters]
        special_prefix = ''.join(random.choice(specials) for _ in range(number_of_characters-len(forced_prefix)))
    else:
        random_alphanumeric_length = 5
        alphanumeric_prefix = get_random_str(number_of_characters=random_alphanumeric_length, allow_upper_case=True)
        special_prefix = ''.join(
            random.choice(specials) for _ in range(number_of_characters - random_alphanumeric_length)
        )

    return f'{alphanumeric_prefix}{special_prefix}'


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime.datetime, datetime.date)):
        return obj.isoformat()
    else:
        return obj.__dict__


def unique(seq):
    seen = set()
    return [x for x in seq if x not in seen and not seen.add(x)]


def get_unique_list_entries_from_list_of_dicts_for_key(list_of_dicts: List[dict], key: str) -> list:
    all_entries_for_key = []
    for entry in list_of_dicts:
        all_entries_for_key.extend(entry.get(key, []))

    return unique(all_entries_for_key)


def get_url_without_query_suffix(url) -> str:
    return url.split('?')[0]


def get_last_value_from_url_params(url) -> str:
    split_url = url.split('=')

    if len(split_url) > 1:
        return split_url[-1]


def natural_sort_key(s, _nsre=re.compile('([0-9]+)')):
    print(s)
    return [
        int(text) if text.isdigit() else text.lower()
        for text in _nsre.split(s)
    ]


def natural_sort_short_name(s, _nsre=re.compile('([0-9]+)')):
    print(s.short_name)
    print(
        [
            int(text) if text.isdigit() else text.lower()
            for text in _nsre.split(s.short_name)
        ]
    )
    print('---')
    return [
        int(text) if text.isdigit() else text.lower()
        for text in _nsre.split(s.short_name)
    ]


def get_query_params_from_url(url: str) -> dict:
    parsed_url = urlparse(url)
    return parse_qs(parsed_url.query)

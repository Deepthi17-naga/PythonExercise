import os

CHROME = 'chrome'
FIREFOX = 'firefox'
SAFARI = 'safari'
EDGE = 'edge'
INTERNET_EXPLORER = 'internet explorer'


def _resolve_selected_browser(selected_browser: str) -> str:
    if CHROME in selected_browser or \
            selected_browser == 'ch' or \
            selected_browser == 'chr':
        return CHROME

    if FIREFOX in selected_browser or \
            selected_browser == 'ff' or \
            selected_browser == 'firef':
        return FIREFOX

    if SAFARI in selected_browser or \
            selected_browser == 'safari' or \
            selected_browser == 's' or \
            selected_browser == 'saf':
        return SAFARI

    if EDGE in selected_browser or \
            selected_browser == 'e' or \
            selected_browser == 'edg':
        return EDGE

    if INTERNET_EXPLORER in selected_browser or \
            selected_browser == 'ie' or \
            'explorer' in selected_browser:
        return INTERNET_EXPLORER


def _resolve_str_into_bool(text: str) -> bool:
    return text.lower() in {'true', 'yes', '1'} if text else False


class Constants:
    config_dir = os.path.dirname(__file__)

    date_time_format_compact = '%Y%m%d%H%M%S'
    date_time_format_readable = '%Y-%m-%d %H:%M:%S'
    date_time_format_iso8601 = '%Y-%m-%dT%H:%M:%S%z'
    date_time_format_for_filename = '%Y%m%d-%H%M%S-%f'
    date_time_format_only_date = '%Y.%m.%d'
    date_time_month_day_time = '%m%d %H%M%S'

    DEFAULT_EXPLICIT_WAIT_SECONDS = 9
    DEFAULT_WAIT_FOR_ELEMENT_SECONDS = 320

    selected_browser = _resolve_selected_browser(os.getenv('SELECTED_BROWSER', 'chrome'))
    browser_headless = _resolve_str_into_bool(os.getenv('BROWSER_HEADLESS', False))
    driver_implicit_wait = int(os.getenv('DRIVER_IMPLICIT_WAIT', 15))

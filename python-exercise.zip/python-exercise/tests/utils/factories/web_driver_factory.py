from selenium import webdriver
from selenium.webdriver.remote.webdriver import WebDriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

from utils.constants import Constants, CHROME, FIREFOX, SAFARI
from utils.helpers import check_if_linux_os, print_debug


class WebDriverFactory:
    constants: Constants
    driver: WebDriver
    options = None
    capabilities: webdriver.DesiredCapabilities

    def __init__(self, constants: Constants):
        self.constants = constants
        self._configure_driver_for_selected_browser()

    def _configure_driver_for_selected_browser(self):
        if self.constants.selected_browser == FIREFOX:
            self.capabilities = webdriver.DesiredCapabilities.FIREFOX.copy()
            self.options = webdriver.FirefoxOptions()
            self.options.headless = self.constants.browser_headless
        elif self.constants.selected_browser == SAFARI:
            self.capabilities = webdriver.DesiredCapabilities.SAFARI.copy()
            # Safari does not support headless (2020-12-08)
        else:  # self.consts.web_driver_helper.selected_browser == CHROME
            self.capabilities = webdriver.DesiredCapabilities.CHROME.copy()
            self.options = webdriver.ChromeOptions()
            self.options.headless = self.constants.browser_headless
            if check_if_linux_os():
                self.options.add_argument('--headless')
                self.options.add_argument('--no-sandbox')
                self.options.add_argument('--disable-dev-shm-usage')

    def _init_driver_for_selected_browser_webdriver_manager(self):
        if self.constants.selected_browser == FIREFOX:
            self.driver = webdriver.Firefox(
                executable_path=GeckoDriverManager().install(),
                options=self.options,
                capabilities=self.capabilities
            )
        elif self.constants.selected_browser == SAFARI:
            self.driver = webdriver.Safari(
                executable_path='/usr/bin/safaridriver',
                desired_capabilities=self.capabilities
            )
        else:  # self.consts.web_driver_helper.selected_browser == CHROME
            self.driver = webdriver.Chrome(
                executable_path=ChromeDriverManager().install(),
                options=self.options,
                desired_capabilities=self.capabilities
            )

    def init_driver(self) -> WebDriver:
        print_debug(f'Init webdriver for {self.constants.selected_browser}')
        self._init_driver_for_selected_browser_webdriver_manager()

        self.driver.implicitly_wait(self.constants.driver_implicit_wait)
        self.driver.maximize_window()
        return self.driver

    def quit_driver(self):
        self.driver.quit()
